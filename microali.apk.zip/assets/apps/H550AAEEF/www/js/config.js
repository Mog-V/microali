var $http='http://vali.wedams.com/ajax/';
var $share='http://vali.wedams.com/page/share.php';
